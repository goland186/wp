<?php
get_header();
?>
<div class="container">
	<?php echo do_shortcode( '[motors_listing_inventory]' ); ?>
</div>
<?php
get_footer();
