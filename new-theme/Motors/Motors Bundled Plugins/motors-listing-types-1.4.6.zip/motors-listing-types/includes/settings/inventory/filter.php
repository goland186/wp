<?php
add_filter( 'mlt_conf_inventory_filter', 'mlt_conf_inventory_filter', 10, 2 );

function mlt_conf_inventory_filter( array $fields, $slug ) {
	$cfto_sidebars  = array();
	$cfto_positions = array();

	if ( function_exists( 'stm_me_wpcfto_sidebars' ) ) {
		$cfto_sidebars = stm_me_wpcfto_sidebars();
	}

	if ( function_exists( 'stm_me_wpcfto_positions' ) ) {
		$cfto_positions = stm_me_wpcfto_positions();
	}

	$skins = apply_filters(
		'mvl_inventory_skins',
		array(
			array(
				'value' => 'default',
				'alt'   => 'Classic',
				'img'   => esc_url( STM_LISTINGS_URL . '/assets/images/pro/inventory/inventory-classic.jpg' ),
			),
			array(
				'value'         => 'inventory-modern',
				'alt'           => 'Modern',
				'img'           => esc_url( STM_LISTINGS_URL . '/assets/images/pro/inventory/inventory-modern.png' ),
				'disabled'      => ! is_mvl_pro(),
				'preview_url'   => 'https://motors-plugin.stylemixthemes.com/inventory/',
				'preview_label' => esc_html__( 'Preview', 'motors_listing_types' ),
				'pricing_url'   => admin_url( 'admin.php?page=mvl-go-pro' ),
				'pricing_label' => esc_html__( 'Upgrade to PRO', 'motors_listing_types' ),
				'lock_icon'     => esc_url( STM_LISTINGS_URL . '/assets/images/pro/lock-pro.svg' ),
			),
			array(
				'value'         => 'inventory-modular',
				'alt'           => 'Modular',
				'img'           => esc_url( STM_LISTINGS_URL . '/assets/images/pro/inventory/inventory-modular.png' ),
				'disabled'      => ! is_mvl_pro(),
				'preview_url'   => 'https://motors-plugin.stylemixthemes.com/modular-inventory/',
				'preview_label' => esc_html__( 'Preview', 'motors_listing_types' ),
				'pricing_url'   => admin_url( 'admin.php?page=mvl-go-pro' ),
				'pricing_label' => esc_html__( 'Upgrade to PRO', 'motors_listing_types' ),
				'lock_icon'     => esc_url( STM_LISTINGS_URL . '/assets/images/pro/lock-pro.svg' ),
			),
		)
	);

	$fields = array_merge(
		$fields,
		array(
			$slug . '_search_filters_settings_title' => array(
				'type'       => 'group_title',
				'label'      => esc_html__( 'Search Filters', 'motors_listing_types' ),
				'submenu'    => esc_html__( 'Inventory Settings', 'motors_listing_types' ),
				'dependency' => array(
					'key'   => $slug . '_inventory_custom_settings',
					'value' => 'not_empty',
				),
				'group'      => 'started',
			),
			$slug . '_inventory_skin'                => array(
				'label'        => esc_html__( 'Inventory Page Skins', 'motors_listing_types' ),
				'type'         => 'nuxy-radio',
				'submenu'      => esc_html__( 'Inventory Settings', 'motors_listing_types' ),
				'width'        => 250,
				'height'       => 150,
				'value'        => 'default',
				'options'      => $skins,
				'dependency'   => array(
					array(
						'key'   => $slug . '_inventory_custom_settings',
						'value' => 'not_empty',
					),
				),
				'dependencies' => '&&',
			),
			$slug . '_multilisting_default_sort_by'  => array(
				'label'        => esc_html__( 'Default sorting by', 'motors_listing_types' ),
				'type'         => 'select',
				'value'        => 'date_high',
				'options'      => multilisting_default_sortby( $slug ),
				'submenu'      => esc_html__( 'Inventory Settings', 'motors_listing_types' ),
				'description'  => esc_html__( 'Select how you want the listings to be sorted', 'motors_listing_types' ),
				'preview'      => STM_LISTINGS_URL . '/assets/images/previews/default-sorting-sf.png',
				'dependency'   => array(
					array(
						'key'   => $slug . '_inventory_custom_settings',
						'value' => 'not_empty',
					),
					array(
						'key'     => 'multilisting_current_motors_layout',
						'value'   => 'ev_dealer||aircrafts||boats||car_dealer||car_dealer_two||car_magazine||listing||listing_two||listing_three||listing_four||listing_five||listing_six||listing_one_elementor||listing_two_elementor||listing_three_elementor||listing_four_elementor||listing_five_elementor||motorcycle',
						'section' => 'listing_types',
					),
				),
				'dependencies' => '&&',
			),
			$slug . '_multilisting_sort_options'     => array(
				'label'        => esc_html__( 'Sort by custom fields', 'motors_listing_types' ),
				'type'         => 'multi_checkbox',
				'preview'      => STM_LISTINGS_URL . '/assets/images/previews/filter-by-sf.png',
				'options'      => stm_multilisting_sort_options( $slug ),
				'submenu'      => esc_html__( 'Inventory Settings', 'motors_listing_types' ),
				'dependency'   => array(
					array(
						'key'   => $slug . '_inventory_custom_settings',
						'value' => 'not_empty',
					),
					array(
						'key'     => 'multilisting_current_motors_layout',
						'value'   => 'ev_dealer||aircrafts||boats||car_dealer||car_dealer_two||car_magazine||listing||listing_two||listing_three||listing_four||listing_five||listing_six||listing_one_elementor||listing_two_elementor||listing_three_elementor||listing_four_elementor||listing_five_elementor||motorcycle',
						'section' => 'listing_types',
					),
				),
				'dependencies' => '&&',
			),
			$slug . '_enable_features_search'        => array(
				'label'        => esc_html__( 'Filter by features', 'motors_listing_types' ),
				'description'  => esc_html__( 'The search results can be filtered based on features', 'motors_listing_types' ),
				'type'         => 'checkbox',
				'preview'      => STM_LISTINGS_URL . '/assets/images/previews/filter-by-features-sf.png',
				'submenu'      => esc_html__( 'Inventory Settings', 'motors_listing_types' ),
				'dependency'   => array(
					array(
						'key'   => $slug . '_inventory_custom_settings',
						'value' => 'not_empty',
					),
					array(
						'key'     => 'multilisting_current_motors_layout',
						'value'   => 'ev_dealer||car_dealer||car_dealer_two||car_magazine||listing||listing_two||listing_three||listing_four||listing_five||listing_six||listing_one_elementor||listing_two_elementor||listing_three_elementor||listing_four_elementor||listing_five_elementor||motorcycle',
						'section' => 'listing_types',
					),
				),
				'dependencies' => '&&',
			),
		),
	);

	if ( is_mvl_pro() ) {
		$fields = array_merge(
			$fields,
			array(
				$slug . '_enable_location'              => array(
					'label'        => esc_html__( 'Filter by location', 'motors_listing_types' ),
					'description'  => esc_html__( 'The search results can be filtered based on location', 'motors_listing_types' ),
					'type'         => 'checkbox',
					'preview'      => STM_LISTINGS_URL . '/assets/images/previews/filter-by-location-sf.png',
					'submenu'      => esc_html__( 'Inventory Settings', 'motors_listing_types' ),
					'dependency'   => array(
						array(
							'key'   => $slug . '_inventory_custom_settings',
							'value' => 'not_empty',
						),
						array(
							'key'     => 'multilisting_current_motors_layout',
							'value'   => 'ev_dealer||boats||car_dealer||car_dealer_two||car_magazine||listing||listing_two||listing_three||listing_four||listing_five||listing_six||listing_one_elementor||listing_two_elementor||listing_three_elementor||listing_four_elementor||listing_five_elementor',
							'section' => 'listing_types',
						),
					),
					'dependencies' => '&&',

				),
				$slug . '_enable_distance_search'       => array(
					'label'        => esc_html__( 'Sort by distance', 'motors_listing_types' ),
					'description'  => esc_html__( 'The results will be shown from the nearest to the farthest for the location', 'motors_listing_types' ),
					'type'         => 'checkbox',
					'submenu'      => esc_html__( 'Inventory Settings', 'motors_listing_types' ),
					'dependency'   => array(
						array(
							'key'   => $slug . '_inventory_custom_settings',
							'value' => 'not_empty',
						),
						array(
							'key'   => $slug . '_enable_location',
							'value' => 'not_empty',
						),
						array(
							'key'     => 'multilisting_current_motors_layout',
							'value'   => 'ev_dealer||boats||car_dealer||car_dealer_two||car_magazine||listing||listing_two||listing_three||listing_four||listing_five||listing_six||listing_one_elementor||listing_two_elementor||listing_three_elementor||listing_four_elementor||listing_five_elementor',
							'section' => 'listing_types',
						),
					),
					'value'        => true,
					'dependencies' => '&&',
				),
				$slug . '_recommend_items_empty_result' => array(
					'label'        => esc_html__( 'Recommend vehicles in other locations in case of empty result', 'motors_listing_types' ),
					'description'  => esc_html__( 'If there are no search results there will be a list of other recommended vehicles', 'motors_listing_types' ),
					'type'         => 'checkbox',
					'submenu'      => esc_html__( 'Inventory Settings', 'motors_listing_types' ),
					'dependency'   => array(
						array(
							'key'   => $slug . '_inventory_custom_settings',
							'value' => 'not_empty',
						),
						array(
							'key'   => $slug . '_enable_location',
							'value' => 'not_empty',
						),
						array(
							'key'   => $slug . '_enable_distance_search',
							'value' => 'empty',
						),
						array(
							'key'     => 'multilisting_current_motors_layout',
							'value'   => 'motorcycle||ev_dealer||boats||car_dealer||car_dealer_two||car_magazine||listing||listing_two||listing_three||listing_four||listing_five||listing_six||listing_one_elementor||listing_two_elementor||listing_three_elementor||listing_four_elementor||listing_five_elementor',
							'section' => 'listing_types',
						),
					),
					'value'        => true,
					'dependencies' => '&&',
				),
				$slug . '_distance_measure_unit'        => array(
					'label'        => esc_html__( 'Unit of measurement', 'motors_listing_types' ),
					'description'  => esc_html__( 'Define a measuring unit for distance', 'motors_listing_types' ),
					'type'         => 'select',
					'options'      =>
						array(
							'miles'      => 'Miles',
							'kilometers' => 'Kilometers',
						),
					'submenu'      => esc_html__( 'Inventory Settings', 'motors_listing_types' ),
					'dependency'   => array(
						array(
							'key'   => $slug . '_inventory_custom_settings',
							'value' => 'not_empty',
						),
						array(
							'key'   => $slug . '_enable_location',
							'value' => 'not_empty',
						),
						array(
							'key'     => 'multilisting_current_motors_layout',
							'value'   => 'motorcycle||ev_dealer||boats||car_dealer||car_dealer_two||car_magazine||listing||listing_two||listing_three||listing_four||listing_five||listing_six||listing_one_elementor||listing_two_elementor||listing_three_elementor||listing_four_elementor||listing_five_elementor',
							'section' => 'listing_types',
						),
					),
					'dependencies' => '&&',
				),
				$slug . '_listing_sidebar'              => array(
					'label'        => esc_html__( 'Inventory Sidebar', 'motors_listing_types' ),
					'type'         => 'select',
					'options'      => $cfto_sidebars,
					'value'        => 'no_sidebar',
					'submenu'      => esc_html__( 'Inventory Settings', 'motors_listing_types' ),
					'dependency'   => array(
						array(
							'key'   => $slug . '_inventory_custom_settings',
							'value' => 'not_empty',
						),
						array(
							'key'     => 'multilisting_current_motors_layout',
							'value'   => 'ev_dealer||aircrafts||boats||car_dealer||car_dealer_two||car_magazine||listing||listing_two||listing_three||listing_four||listing_five||listing_six||listing_one_elementor||listing_two_elementor||listing_three_elementor||listing_four_elementor||listing_five_elementor||motorcycle',
							'section' => 'listing_types',
						),
					),
					'dependencies' => '&&',
				),
				$slug . '_sidebar_filter_bg'            => array(
					'label'        => esc_html__( 'Listing Sidebar Filter Background', 'motors_listing_types' ),
					'type'         => 'image',
					'submenu'      => esc_html__( 'Inventory Settings', 'motors_listing_types' ),
					'dependency'   => array(
						array(
							'key'   => $slug . '_inventory_custom_settings',
							'value' => 'not_empty',
						),
						array(
							'key'     => 'multilisting_current_motors_layout',
							'value'   => 'listing',
							'section' => 'listing_types',
						),
					),
					'dependencies' => '&&',
				),
				$slug . '_distance_search'              => array(
					'label'        => esc_html__( 'Max search radius', 'motors_listing_types' ),
					'description'  => esc_html__( 'Put the maximum search radius', 'motors_listing_types' ),
					'type'         => 'text',
					'submenu'      => esc_html__( 'Inventory Settings', 'motors_listing_types' ),
					'dependency'   => array(
						array(
							'key'   => $slug . '_inventory_custom_settings',
							'value' => 'not_empty',
						),
						array(
							'key'   => $slug . '_enable_location',
							'value' => 'not_empty',
						),
						array(
							'key'   => $slug . '_enable_distance_search',
							'value' => 'not_empty',
						),
						array(
							'key'     => 'multilisting_current_motors_layout',
							'value'   => 'ev_dealer||boats||car_dealer||car_dealer_two||car_magazine||listing||listing_two||listing_three||listing_four||listing_five||listing_six||listing_one_elementor||listing_two_elementor||listing_three_elementor||listing_four_elementor||listing_five_elementor',
							'section' => 'listing_types',
						),
					),
					'dependencies' => '&&',
					'group'        => 'ended',
				),
			)
		);
	} else {
		$fields[ array_key_last( $fields ) ]['group'] = 'ended';
	}

	return $fields;
}
