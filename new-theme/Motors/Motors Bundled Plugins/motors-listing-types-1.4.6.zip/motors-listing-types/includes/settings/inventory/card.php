<?php
add_filter( 'mlt_conf_inventory_card', 'mlt_conf_inventory_card', 10, 2 );

function mlt_conf_inventory_card( array $fields, $slug ) {
	$filter_options = multilisting_get_type_taxonomies( $slug );
	$taxonomies     = array( '' => esc_html__( 'None', 'motors_listing_types' ) );

	$skins = array(
		$slug . '_grid_card_skin' => array(
			'type'         => 'nuxy-radio',
			'label'        => esc_html__( 'Listing Card Skins', 'motors_listing_types' ),
			'value'        => 'default',
			'options'      => array(
				array(
					'value' => 'default',
					'alt'   => 'Classic',
					'img'   => STM_LISTINGS_URL . '/assets/images/pro/listing-card/grid-default.png',
				),
				array(
					'value'         => 'skin_1',
					'alt'           => 'Modern',
					'img'           => STM_LISTINGS_URL . '/assets/images/pro/listing-card/grid-1.png',
					'disabled'      => ! is_mvl_pro(),
					'preview_url'   => 'https://motors-plugin.stylemixthemes.com/modern-card-skin?view_type=grid',
					'preview_label' => esc_html__( 'Preview', 'motors_listing_types' ),
					'pricing_url'   => admin_url( 'admin.php?page=mvl-go-pro' ),
					'pricing_label' => esc_html__( 'Upgrade to PRO', 'motors_listing_types' ),
					'lock_icon'     => esc_url( STM_LISTINGS_URL . '/assets/images/pro/lock-pro.svg' ),
				),
				array(
					'value'         => 'skin_2',
					'alt'           => 'Elegant',
					'img'           => STM_LISTINGS_URL . '/assets/images/pro/listing-card/grid-2.png',
					'disabled'      => ! is_mvl_pro(),
					'preview_url'   => 'https://motors-plugin.stylemixthemes.com/elegant-card-skin?view_type=grid',
					'preview_label' => esc_html__( 'Preview', 'motors_listing_types' ),
					'pricing_url'   => admin_url( 'admin.php?page=mvl-go-pro' ),
					'pricing_label' => esc_html__( 'Upgrade to PRO', 'motors_listing_types' ),
					'lock_icon'     => esc_url( STM_LISTINGS_URL . '/assets/images/pro/lock-pro.svg' ),
				),
				array(
					'value'         => 'skin_3',
					'alt'           => 'Compact',
					'img'           => STM_LISTINGS_URL . '/assets/images/pro/listing-card/grid-3.png',
					'disabled'      => ! is_mvl_pro(),
					'preview_url'   => 'https://motors-plugin.stylemixthemes.com/compact-card-skin?view_type=grid',
					'preview_label' => esc_html__( 'Preview', 'motors_listing_types' ),
					'pricing_url'   => admin_url( 'admin.php?page=mvl-go-pro' ),
					'pricing_label' => esc_html__( 'Upgrade to PRO', 'motors_listing_types' ),
					'lock_icon'     => esc_url( STM_LISTINGS_URL . '/assets/images/pro/lock-pro.svg' ),
				),
				array(
					'value'         => 'skin_4',
					'alt'           => 'Luxury',
					'img'           => STM_LISTINGS_URL . '/assets/images/pro/listing-card/grid-4.png',
					'disabled'      => ! is_mvl_pro(),
					'preview_url'   => 'https://motors-plugin.stylemixthemes.com/luxury-card-skin?view_type=grid',
					'preview_label' => esc_html__( 'Preview', 'motors_listing_types' ),
					'pricing_url'   => admin_url( 'admin.php?page=mvl-go-pro' ),
					'pricing_label' => esc_html__( 'Upgrade to PRO', 'motors_listing_types' ),
					'lock_icon'     => esc_url( STM_LISTINGS_URL . '/assets/images/pro/lock-pro.svg' ),
				),
			),
			'dependency'   => array(
				array(
					'key'   => $slug . '_inventory_custom_settings',
					'value' => 'not_empty',
				),
				array(
					'key'   => $slug . '_listing_view_type',
					'value' => 'grid',
				),
			),
			'dependencies' => '&&',
			'submenu'      => esc_html__( 'Inventory Settings', 'motors_listing_types' ),
		),
		'list_card_skin'          => array(
			'type'         => 'data_select',
			'label'        => esc_html__( 'Listing Card Skins', 'motors_listing_types' ),
			'value'        => 'default',
			'options'      => array(
				array(
					'value' => 'default',
					'alt'   => 'Classic',
					'img'   => STM_LISTINGS_URL . '/assets/images/pro/listing-card/list-default.png',
				),
				array(
					'value'         => 'skin_1',
					'alt'           => 'Modern',
					'img'           => STM_LISTINGS_URL . '/assets/images/pro/listing-card/list-1.png',
					'disabled'      => ! is_mvl_pro(),
					'preview_url'   => 'https://motors-plugin.stylemixthemes.com/modern-card-skin?view_type=list',
					'preview_label' => esc_html__( 'Preview', 'motors_listing_types' ),
					'pricing_url'   => admin_url( 'admin.php?page=mvl-go-pro' ),
					'pricing_label' => esc_html__( 'Upgrade to PRO', 'motors_listing_types' ),
					'lock_icon'     => esc_url( STM_LISTINGS_URL . '/assets/images/pro/lock-pro.svg' ),
				),
				array(
					'value'         => 'skin_2',
					'alt'           => 'Elegant',
					'img'           => STM_LISTINGS_URL . '/assets/images/pro/listing-card/list-2.png',
					'disabled'      => ! is_mvl_pro(),
					'preview_url'   => 'https://motors-plugin.stylemixthemes.com/elegant-card-skin?view_type=list',
					'preview_label' => esc_html__( 'Preview', 'motors_listing_types' ),
					'pricing_url'   => admin_url( 'admin.php?page=mvl-go-pro' ),
					'pricing_label' => esc_html__( 'Upgrade to PRO', 'motors_listing_types' ),
					'lock_icon'     => esc_url( STM_LISTINGS_URL . '/assets/images/pro/lock-pro.svg' ),
				),
				array(
					'value'         => 'skin_3',
					'alt'           => 'Compact',
					'img'           => STM_LISTINGS_URL . '/assets/images/pro/listing-card/list-3.png',
					'disabled'      => ! is_mvl_pro(),
					'preview_url'   => 'https://motors-plugin.stylemixthemes.com/compact-card-skin?view_type=list',
					'preview_label' => esc_html__( 'Preview', 'motors_listing_types' ),
					'pricing_url'   => admin_url( 'admin.php?page=mvl-go-pro' ),
					'pricing_label' => esc_html__( 'Upgrade to PRO', 'motors_listing_types' ),
					'lock_icon'     => esc_url( STM_LISTINGS_URL . '/assets/images/pro/lock-pro.svg' ),
				),
				array(
					'value'         => 'skin_4',
					'alt'           => 'Luxury',
					'img'           => STM_LISTINGS_URL . '/assets/images/pro/listing-card/list-4.png',
					'disabled'      => ! is_mvl_pro(),
					'preview_url'   => 'https://motors-plugin.stylemixthemes.com/luxury-card-skin?view_type=list',
					'preview_label' => esc_html__( 'Preview', 'motors_listing_types' ),
					'pricing_url'   => admin_url( 'admin.php?page=mvl-go-pro' ),
					'pricing_label' => esc_html__( 'Upgrade to PRO', 'motors_listing_types' ),
					'lock_icon'     => esc_url( STM_LISTINGS_URL . '/assets/images/pro/lock-pro.svg' ),
				),
			),
			'dependency'   => array(
				array(
					'key'   => $slug . '_inventory_custom_settings',
					'value' => 'not_empty',
				),
				array(
					'key'   => $slug . '_listing_view_type',
					'value' => 'list',
				),
			),
			'dependencies' => '&&',
			'submenu'      => esc_html__( 'Inventory Settings', 'motors_listing_types' ),
		),
	);

	$fields[ $slug . '_listing_card_settings_title' ] = array(
		'type'       => 'group_title',
		'label'      => esc_html__( 'Listing Card', 'motors_listing_types' ),
		'submenu'    => esc_html__( 'Inventory Settings', 'motors_listing_types' ),
		'dependency' => array(
			'key'   => $slug . '_inventory_custom_settings',
			'value' => 'not_empty',
		),
		'group'      => 'started',
	);

	$fields = array_merge( $fields, $skins );

	return array_merge(
		$fields,
		array(
			$slug . '_hide_price_labels'                => array(
				'label'        => esc_html__( 'Hide Price Labels on Listing Archive', 'motors_listing_types' ),
				'type'         => 'checkbox',
				'submenu'      => esc_html__( 'Inventory Settings', 'motors_listing_types' ),
				'dependency'   => array(
					array(
						'key'   => $slug . '_inventory_custom_settings',
						'value' => 'not_empty',
					),
					array(
						'key'     => 'multilisting_current_motors_layout',
						'value'   => 'aircrafts||car_dealer_two||car_magazine||listing||listing_two||listing_three||listing_four||listing_five||listing_six||listing_one_elementor||listing_two_elementor||listing_three_elementor||listing_four_elementor||listing_five_elementor',
						'section' => 'listing_types',
					),
				),
				'dependencies' => '&&',
			),

			$slug . '_listing_view_type'                => array(
				'label'        => esc_html__( 'Listing View Type', 'motors_listing_types' ),
				'type'         => 'radio',
				'options'      =>
					array(
						'grid' => 'Grid',
						'list' => 'List',
					),
				'value'        => 'list',
				'submenu'      => esc_html__( 'Inventory Settings', 'motors_listing_types' ),
				'dependency'   => array(
					array(
						'key'   => $slug . '_inventory_custom_settings',
						'value' => 'not_empty',
					),
					array(
						'key'     => 'multilisting_current_motors_layout',
						'value'   => 'ev_dealer||aircrafts||boats||car_dealer||car_dealer_two||car_magazine||listing||listing_two||listing_three||listing_four||listing_five||listing_six||listing_one_elementor||listing_two_elementor||listing_three_elementor||listing_four_elementor||listing_five_elementor||motorcycle',
						'section' => 'listing_types',
					),
				),
				'dependencies' => '&&',
			),
			$slug . '_listing_view_type_mobile'         => array(
				'label'        => esc_html__( 'Mobile Listing View Type', 'motors_listing_types' ),
				'type'         => 'radio',
				'options'      =>
					array(
						'grid' => 'Grid',
						'list' => 'List',
					),
				'value'        => 'grid',
				'submenu'      => esc_html__( 'Inventory Settings', 'motors_listing_types' ),
				'dependency'   => array(
					array(
						'key'   => $slug . '_inventory_custom_settings',
						'value' => 'not_empty',
					),
					array(
						'key'     => 'multilisting_current_motors_layout',
						'value'   => 'ev_dealer||aircrafts||boats||car_dealer||car_dealer_two||car_magazine||listing||listing_two||listing_three||listing_four||listing_five||listing_six||listing_one_elementor||listing_two_elementor||listing_three_elementor||listing_four_elementor||listing_five_elementor||motorcycle',
						'section' => 'listing_types',
					),
				),
				'dependencies' => '&&',
			),
			$slug . '_grid_title_max_length'            => array(
				'label'        => esc_html__( 'Grid Item Title Max Length', 'motors_listing_types' ),
				'type'         => 'text',
				'value'        => '44',
				'submenu'      => esc_html__( 'Inventory Settings', 'motors_listing_types' ),
				'dependency'   => array(
					array(
						'key'   => $slug . '_inventory_custom_settings',
						'value' => 'not_empty',
					),
					array(
						'key'   => $slug . '_listing_view_type',
						'value' => 'grid',
					),
				),
				'dependencies' => '&&',
			),

			$slug . '_enable_favorite_items'            => array(
				'label'        => esc_html__( 'Enable Favorite Button', 'motors_listing_types' ),
				'type'         => 'checkbox',
				'submenu'      => esc_html__( 'Inventory Settings', 'motors_listing_types' ),
				'dependency'   => array(
					array(
						'key'   => $slug . '_inventory_custom_settings',
						'value' => 'not_empty',
					),
					array(
						'key'     => 'multilisting_current_motors_layout',
						'value'   => 'listing||listing_two||listing_three||listing_four||listing_five||listing_six||listing_one_elementor||listing_two_elementor||listing_three_elementor||listing_four_elementor||listing_five_elementor',
						'section' => 'listing_types',
					),
				),
				'dependencies' => '&&',
			),

			$slug . '_listing_directory_title_frontend' => array(
				'label'       => esc_html__( 'Display Generated Listing Title as:', 'motors_listing_types' ),
				'type'        => 'multiselect',
				'options'     => multilisting_get_type_taxonomies( $slug ),
				'description' => sprintf( __( 'The title will be generated based on the %s categories.', 'motors_listing_types' ), $slug ),
                //phpcs:ignore
                'submenu'     => esc_html__( 'Inventory Settings', 'motors_listing_types' ),
				'dependency'  => array(
					'key'   => $slug . '_inventory_custom_settings',
					'value' => 'not_empty',
				),
			),
			$slug . '_show_generated_title_as_label'    => array(
				'label'        => esc_html__( 'Show Two First Parameters as a Badge', 'motors_listing_types' ),
				'type'         => 'checkbox',
				'description'  => 'Archive Page and Single Listing',
				'submenu'      => esc_html__( 'Inventory Settings', 'motors_listing_types' ),
				'dependency'   => array(
					array(
						'key'   => $slug . '_inventory_custom_settings',
						'value' => 'not_empty',
					),
					array(
						'key'   => $slug . '_listing_view_type',
						'value' => 'list',
					),
					array(
						'key'     => 'multilisting_current_motors_layout',
						'value'   => 'ev_dealer||aircrafts||car_dealer_two||car_magazine||listing||listing_two||listing_three||listing_four||listing_five||listing_six||listing_one_elementor||listing_two_elementor||listing_three_elementor||listing_four_elementor||listing_five_elementor||motorcycle',
						'section' => 'listing_types',
					),
				),
				'dependencies' => '&&',
			),
			$slug . '_listing_directory_enable_dealer_info' => array(
				'label'        => esc_html__( 'Enable Dealer Info on Listing', 'motors_listing_types' ),
				'type'         => 'checkbox',
				'submenu'      => esc_html__( 'Inventory Settings', 'motors_listing_types' ),
				'dependency'   => array(
					array(
						'key'   => $slug . '_inventory_custom_settings',
						'value' => 'not_empty',
					),
					array(
						'key'   => $slug . '_listing_view_type',
						'value' => 'list',
					),
					array(
						'key'     => 'multilisting_current_motors_layout',
						'value'   => 'listing||listing_two||listing_three||listing_four||listing_five||listing_six||listing_one_elementor||listing_two_elementor||listing_three_elementor||listing_four_elementor||listing_five_elementor||aircrafts',
						'section' => 'listing_types',
					),
				),
				'dependencies' => '&&',
			),
			$slug . '_show_listing_stock'               => array(
				'label'        => esc_html__( 'Show Stock', 'motors_listing_types' ),
				'type'         => 'checkbox',
				'submenu'      => esc_html__( 'Inventory Settings', 'motors_listing_types' ),
				'dependency'   => array(
					array(
						'key'   => $slug . '_inventory_custom_settings',
						'value' => 'not_empty',
					),
					array(
						'key'   => $slug . '_listing_view_type',
						'value' => 'list',
					),
					array(
						'key'     => 'multilisting_current_motors_layout',
						'value'   => 'ev_dealer||car_dealer||car_dealer_two||car_magazine||listing||listing_two||listing_three||listing_four||listing_five||listing_six||listing_one_elementor||listing_two_elementor||listing_three_elementor||listing_four_elementor||listing_five_elementor||motorcycle',
						'section' => 'listing_types',
					),
				),
				'dependencies' => '&&',
			),
			$slug . '_show_listing_test_drive'          => array(
				'label'        => esc_html__( 'Show Test Drive Schedule', 'motors_listing_types' ),
				'type'         => 'checkbox',
				'submenu'      => esc_html__( 'Inventory Settings', 'motors_listing_types' ),
				'dependency'   => array(
					array(
						'key'   => $slug . '_inventory_custom_settings',
						'value' => 'not_empty',
					),
					array(
						'key'   => $slug . '_listing_view_type',
						'value' => 'list',
					),
					array(
						'key'     => 'multilisting_current_motors_layout',
						'value'   => 'ev_dealer||aircrafts||car_dealer||car_dealer_two||car_magazine||listing||listing_two||listing_three||listing_four||listing_five||listing_six||listing_one_elementor||listing_two_elementor||listing_three_elementor||listing_four_elementor||listing_five_elementor||motorcycle',
						'section' => 'listing_types',
					),
				),
				'dependencies' => '&&',
			),
			$slug . '_show_listing_compare'             => array(
				'label'        => esc_html__( 'Show Compare', 'motors_listing_types' ),
				'type'         => 'checkbox',
				'submenu'      => esc_html__( 'Inventory Settings', 'motors_listing_types' ),
				'dependency'   => array(
					array(
						'key'   => $slug . '_inventory_custom_settings',
						'value' => 'not_empty',
					),
					array(
						'key'     => 'multilisting_current_motors_layout',
						'value'   => 'ev_dealer||aircrafts||boats||car_dealer||car_dealer_two||car_magazine||listing||listing_two||listing_three||listing_four||listing_five||listing_six||listing_one_elementor||listing_two_elementor||listing_three_elementor||listing_four_elementor||listing_five_elementor||motorcycle',
						'section' => 'listing_types',
					),
				),
				'dependencies' => '&&',
			),
			$slug . '_show_listing_share'               => array(
				'label'        => esc_html__( 'Show Share Block', 'motors_listing_types' ),
				'type'         => 'checkbox',
				'submenu'      => esc_html__( 'Inventory Settings', 'motors_listing_types' ),
				'dependency'   => array(
					array(
						'key'   => $slug . '_inventory_custom_settings',
						'value' => 'not_empty',
					),
					array(
						'key'   => $slug . '_listing_view_type',
						'value' => 'list',
					),
					array(
						'key'     => 'multilisting_current_motors_layout',
						'value'   => 'ev_dealer||aircrafts||car_dealer||car_dealer_two||car_magazine||listing||listing_two||listing_three||listing_four||listing_five||listing_six||listing_one_elementor||listing_two_elementor||listing_three_elementor||listing_four_elementor||listing_five_elementor||motorcycle',
						'section' => 'listing_types',
					),
				),
				'dependencies' => '&&',
			),
			$slug . '_show_listing_pdf'                 => array(
				'label'        => esc_html__( 'Show PDF brochure', 'motors_listing_types' ),
				'type'         => 'checkbox',
				'submenu'      => esc_html__( 'Inventory Settings', 'motors_listing_types' ),
				'dependency'   => array(
					array(
						'key'   => $slug . '_inventory_custom_settings',
						'value' => 'not_empty',
					),
					array(
						'key'   => $slug . '_listing_view_type',
						'value' => 'list',
					),
					array(
						'key'     => 'multilisting_current_motors_layout',
						'value'   => 'ev_dealer||aircrafts||car_dealer||car_dealer_two||car_magazine||listing||listing_two||listing_three||listing_four||listing_five||listing_six||listing_one_elementor||listing_two_elementor||listing_three_elementor||listing_four_elementor||listing_five_elementor',
						'section' => 'listing_types',
					),
				),
				'dependencies' => '&&',
			),
			$slug . '_show_listing_certified_logo_1'    => array(
				'label'        => esc_html__( 'Show Certified Logo 1', 'motors_listing_types' ),
				'type'         => 'checkbox',
				'submenu'      => esc_html__( 'Inventory Settings', 'motors_listing_types' ),
				'dependency'   => array(
					array(
						'key'   => $slug . '_inventory_custom_settings',
						'value' => 'not_empty',
					),
					array(
						'key'   => $slug . '_listing_view_type',
						'value' => 'list',
					),
					array(
						'key'     => 'multilisting_current_motors_layout',
						'value'   => 'ev_dealer||aircrafts||car_dealer||car_dealer_two||car_magazine||listing||listing_two||listing_three||listing_four||listing_five||listing_six||listing_one_elementor||listing_two_elementor||listing_three_elementor||listing_four_elementor||listing_five_elementor',
						'section' => 'listing_types',
					),
				),
				'dependencies' => '&&',
			),
			$slug . '_show_listing_certified_logo_2'    => array(
				'label'        => esc_html__( 'Show Certified Logo 2', 'motors_listing_types' ),
				'type'         => 'checkbox',
				'submenu'      => esc_html__( 'Inventory Settings', 'motors_listing_types' ),
				'dependency'   => array(
					array(
						'key'   => $slug . '_inventory_custom_settings',
						'value' => 'not_empty',
					),
					array(
						'key'   => $slug . '_listing_view_type',
						'value' => 'list',
					),
					array(
						'key'     => 'multilisting_current_motors_layout',
						'value'   => 'ev_dealer||aircrafts||car_dealer||car_dealer_two||car_magazine||listing||listing_two||listing_three||listing_four||listing_five||listing_six||listing_one_elementor||listing_two_elementor||listing_three_elementor||listing_four_elementor||listing_five_elementor',
						'section' => 'listing_types',
					),
				),
				'dependencies' => '&&',
				'group'        => 'ended',
			),
		),
	);
}
