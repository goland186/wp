<?php
add_filter( 'mlt_conf_inventory_monetization', 'mlt_conf_inventory_monetization', 10, 2 );

function mlt_conf_inventory_monetization( array $fields, $slug ) {
	return array_merge(
		$fields,
		array(
			$slug . '_monetization_settings_title'    => array(
				'type'       => 'group_title',
				'label'      => esc_html__( 'Monetization', 'motors_listing_types' ),
				'submenu'    => esc_html__( 'Inventory Settings', 'motors_listing_types' ),
				'dependency' => array(
					'key'   => $slug . '_inventory_custom_settings',
					'value' => 'not_empty',
				),
				'group'      => 'started',
			),
			$slug . '_dealer_pay_per_listing'         => array(
				'label'        => esc_html__( 'Enable Pay Per Listing', 'motors_listing_types' ),
				'type'         => 'checkbox',
				'submenu'      => esc_html__( 'Inventory Settings', 'motors_listing_types' ),
				'dependency'   => array(
					array(
						'key'   => $slug . '_inventory_custom_settings',
						'value' => 'not_empty',
					),
					array(
						'key'     => 'multilisting_current_motors_layout',
						'value'   => 'listing||listing_two||listing_three||listing_four||listing_five||listing_six||listing_one_elementor||listing_two_elementor||listing_three_elementor||listing_four_elementor||listing_five_elementor',
						'section' => 'listing_types',
					),
				),
				'dependencies' => '&&',
			),
			$slug . '_pay_per_listing_price'          => array(
				'label'        => esc_html__( 'Pay Per Listing Price', 'motors_listing_types' ),
				'type'         => 'text',
				'value'        => '0',
				'submenu'      => esc_html__( 'Inventory Settings', 'motors_listing_types' ),
				'dependency'   => array(
					array(
						'key'   => $slug . '_dealer_pay_per_listing',
						'value' => 'not_empty',
					),
					array(
						'key'   => $slug . '_inventory_custom_settings',
						'value' => 'not_empty',
					),
					array(
						'key'     => 'multilisting_current_motors_layout',
						'value'   => 'listing||listing_two||listing_three||listing_four||listing_five||listing_six||listing_one_elementor||listing_two_elementor||listing_three_elementor||listing_four_elementor||listing_five_elementor',
						'section' => 'listing_types',
					),
				),
				'dependencies' => '&&',
			),
			$slug . '_pay_per_listing_period'         => array(
				'label'        => esc_html__( 'Pay Per Listing Period (days)', 'motors_listing_types' ),
				'type'         => 'text',
				'value'        => '30',
				'submenu'      => esc_html__( 'Inventory Settings', 'motors_listing_types' ),
				'dependency'   => array(
					array(
						'key'   => $slug . '_dealer_pay_per_listing',
						'value' => 'not_empty',
					),
					array(
						'key'   => $slug . '_inventory_custom_settings',
						'value' => 'not_empty',
					),
					array(
						'key'     => 'multilisting_current_motors_layout',
						'value'   => 'listing||listing_two||listing_three||listing_four||listing_five||listing_six||listing_one_elementor||listing_two_elementor||listing_three_elementor||listing_four_elementor||listing_five_elementor',
						'section' => 'listing_types',
					),
				),
				'dependencies' => '&&',
			),
			$slug . '_dealer_payments_for_featured_listing' => array(
				'label'        => esc_html__( 'Enable Paid Featured Listing', 'motors_listing_types' ),
				'type'         => 'checkbox',
				'submenu'      => esc_html__( 'Inventory Settings', 'motors_listing_types' ),
				'dependency'   => array(
					array(
						'key'   => $slug . '_inventory_custom_settings',
						'value' => 'not_empty',
					),
					array(
						'key'     => 'multilisting_current_motors_layout',
						'value'   => 'listing||listing_two||listing_three||listing_four||listing_five||listing_six||listing_one_elementor||listing_two_elementor||listing_three_elementor||listing_four_elementor||listing_five_elementor',
						'section' => 'listing_types',
					),
				),
				'dependencies' => '&&',
			),
			$slug . '_featured_listing_default_badge' => array(
				'label'        => esc_html__( 'Featured Listing Label', 'motors_listing_types' ),
				'type'         => 'text',
				'value'        => 'Special',
				'submenu'      => esc_html__( 'Inventory Settings', 'motors_listing_types' ),
				'dependency'   => array(
					array(
						'key'   => $slug . '_dealer_payments_for_featured_listing',
						'value' => 'not_empty',
					),
					array(
						'key'   => $slug . '_inventory_custom_settings',
						'value' => 'not_empty',
					),
					array(
						'key'     => 'multilisting_current_motors_layout',
						'value'   => 'listing||listing_two||listing_three||listing_four||listing_five||listing_six||listing_one_elementor||listing_two_elementor||listing_three_elementor||listing_four_elementor||listing_five_elementor',
						'section' => 'listing_types',
					),
				),
				'dependencies' => '&&',
			),
			$slug . '_featured_listing_price'         => array(
				'label'        => esc_html__( 'Featured Listing Price', 'motors_listing_types' ),
				'type'         => 'text',
				'value'        => '0',
				'submenu'      => esc_html__( 'Inventory Settings', 'motors_listing_types' ),
				'dependency'   => array(
					array(
						'key'   => $slug . '_dealer_payments_for_featured_listing',
						'value' => 'not_empty',
					),
					array(
						'key'   => $slug . '_inventory_custom_settings',
						'value' => 'not_empty',
					),
					array(
						'key'     => 'multilisting_current_motors_layout',
						'value'   => 'listing||listing_two||listing_three||listing_four||listing_five||listing_six||listing_one_elementor||listing_two_elementor||listing_three_elementor||listing_four_elementor||listing_five_elementor',
						'section' => 'listing_types',
					),
				),
				'dependencies' => '&&',
			),
			$slug . '_featured_listing_period'        => array(
				'label'        => esc_html__( 'Featured Listing Period (days)', 'motors_listing_types' ),
				'type'         => 'text',
				'value'        => '30',
				'submenu'      => esc_html__( 'Inventory Settings', 'motors_listing_types' ),
				'dependency'   => array(
					array(
						'key'   => $slug . '_dealer_payments_for_featured_listing',
						'value' => 'not_empty',
					),
					array(
						'key'   => $slug . '_inventory_custom_settings',
						'value' => 'not_empty',
					),
					array(
						'key'     => 'multilisting_current_motors_layout',
						'value'   => 'listing||listing_two||listing_three||listing_four||listing_five||listing_six||listing_one_elementor||listing_two_elementor||listing_three_elementor||listing_four_elementor||listing_five_elementor',
						'section' => 'listing_types',
					),
				),
				'dependencies' => '&&',
				'group'        => 'ended',
			),
		),
	);
}
